/**
 * 
 */

function launchReport() {
	/*var chart_window = window.open("showchart.jsp?problemid="+$('input[name=selected_problem]').val(), "mywindow1", "width=1000,height=665,top=0,left=0");*/
	
	my_window = window.open("graphs.jsp", "my", "scrollbars=1,status=1,width=1102,height=800,top=0,left=0,toolbar=no, menubar=no");
	
	
}